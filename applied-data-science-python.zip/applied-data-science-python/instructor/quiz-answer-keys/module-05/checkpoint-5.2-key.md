# Checkpoint 5.2 — Supervised Learning (Answer Key)

7 questions · untimed · covers Unit 5.2. Choose one answer per question.

**1. Logistic regression is mainly used for…**  _(Multiple choice)_

- A) predicting prices
- B) binary classification ✅
- C) clustering
- D) scaling

> **Answer: B.** Despite its name, it classifies.

**2. Which method returns class probabilities?**  _(Multiple choice)_

- A) `predict()`
- B) `predict_proba()` ✅
- C) `score()`
- D) `fit()`

> **Answer: B.** predict_proba returns one column per class.

**3. A confusion matrix shows…**  _(Multiple choice)_

- A) feature correlations
- B) correct and incorrect predictions by class ✅
- C) residuals
- D) cluster centres

> **Answer: B.** Rows = actual, columns = predicted.

**4. RMSE is measured in…**  _(Multiple choice)_

- A) squared units
- B) the same units as y ✅
- C) percent
- D) no units

> **Answer: B.** Square root of MSE.

**5. In `LinearRegression`, the slopes are stored in…**  _(Multiple choice)_

- A) `.coef_` ✅
- B) `.intercept_`
- C) `.labels_`
- D) `.params`

> **Answer: A.** coef_ (one per feature).

**6. An R² of 1.0 means the model explains all variation in the test data.**  _(True/False)_

- A) True ✅
- B) False

> **Answer: A.** Perfect fit (and suspicious in practice).

**7. If 62% of passengers died, a model with 60% accuracy is…**  _(Multiple choice)_

- A) excellent
- B) worse than always guessing 'died' ✅
- C) perfect
- D) overfitted

> **Answer: B.** Always compare to a baseline.

