# Checkpoint 4.4 — Correlation and Regression Analysis (Answer Key)

5 questions · untimed · covers Unit 4.4. Choose one answer per question.

**1. In `sm.OLS(y, X)`, what does `sm.add_constant` add?**  _(Multiple choice)_

- A) A slope
- B) An intercept column of 1s ✅
- C) Noise
- D) A second variable

> **Answer: B.** Without it the line is forced through the origin.

**2. R² = 0.47 means the model explains about…**  _(Multiple choice)_

- A) 4.7% of variation
- B) 47% of variation in y ✅
- C) 47% accuracy
- D) 0.47 units

> **Answer: B.** Share of variance explained.

**3. Slope = 41,800 for income (in $10k) on house value means…**  _(Multiple choice)_

- A) houses cost $41,800
- B) +$10k income → about +$41,800 value ✅
- C) income causes prices
- D) R² is 41,800

> **Answer: B.** Change in y per one-unit change in x.

**4. Residuals should be randomly scattered around zero.**  _(True/False)_

- A) True ✅
- B) False

> **Answer: A.** Patterns suggest the model misses something.

**5. Can a regression coefficient be significant but practically tiny?**  _(Yes/No)_

- A) Yes ✅
- B) No

> **Answer: A.** Significance is not importance.

