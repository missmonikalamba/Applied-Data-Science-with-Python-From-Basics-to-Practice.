# Checkpoint 2.1 — Introduction to Data Preprocessing (Answer Key)

5 questions · untimed · covers Unit 2.1. Choose one answer per question.

**1. Which is NOT a data quality dimension?**  _(Multiple choice)_

- A) Completeness
- B) Consistency
- C) Popularity ✅
- D) Timeliness

> **Answer: C.** The four covered are completeness, consistency, accuracy and timeliness.

**2. Most real-world datasets are analysis-ready as soon as they are loaded.**  _(True/False)_

- A) True
- B) False ✅

> **Answer: B.** Raw data usually needs cleaning first.

**3. Which converts a text column to dates?**  _(Multiple choice)_

- A) `astype(int)`
- B) `pd.to_datetime()` ✅
- C) `pd.to_date()`
- D) `df.dates()`

> **Answer: B.** pd.to_datetime parses strings into datetime64.

**4. 'Low / Medium / High' is an example of…**  _(Multiple choice)_

- A) nominal data
- B) ordinal data ✅
- C) continuous data
- D) datetime data

> **Answer: B.** Ordered categories are ordinal.

**5. Does `df.dtypes` list the data type of every column?**  _(Yes/No)_

- A) Yes ✅
- B) No

> **Answer: A.** dtypes returns a Series of column types.

