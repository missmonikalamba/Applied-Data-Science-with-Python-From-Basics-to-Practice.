# Checkpoint 4.3 — Hypothesis Testing (Answer Key)

6 questions · untimed · covers Unit 4.3. Choose one answer per question.

**1. The null hypothesis usually states…**  _(Multiple choice)_

- A) there is an effect
- B) there is no effect or difference ✅
- C) the sample is wrong
- D) p < 0.05

> **Answer: B.** H₀ is the 'nothing going on' claim.

**2. Rejecting a true H₀ is a…**  _(Multiple choice)_

- A) Type I error ✅
- B) Type II error
- C) power
- D) confidence level

> **Answer: A.** A false positive.

**3. With α = 0.05, a p-value of 0.003 means…**  _(Multiple choice)_

- A) do not reject H₀
- B) reject H₀ ✅
- C) accept H₀
- D) the test failed

> **Answer: B.** p < α.

**4. Comparing the same patients before and after treatment uses…**  _(Multiple choice)_

- A) `ttest_ind`
- B) `ttest_rel` ✅
- C) `chi2_contingency`
- D) `f_oneway`

> **Answer: B.** Paired samples: ttest_rel.

**5. Testing whether gender and product choice are independent uses…**  _(Multiple choice)_

- A) ANOVA
- B) Chi-square test ✅
- C) Paired t-test
- D) Pearson r

> **Answer: B.** Two categorical variables.

**6. One-way ANOVA compares the means of three or more groups.**  _(True/False)_

- A) True ✅
- B) False

> **Answer: A.** scipy.stats.f_oneway.

