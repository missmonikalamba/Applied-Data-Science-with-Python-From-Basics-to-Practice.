# Checkpoint 3.1 — Basic Plotting with Matplotlib (Answer Key)

6 questions · untimed · covers Unit 3.1. Choose one answer per question.

**1. The standard import for Matplotlib's plotting interface is…**  _(Multiple choice)_

- A) import matplotlib as plt
- B) import matplotlib.pyplot as plt ✅
- C) from matplotlib import plot
- D) import pyplot

> **Answer: B.** pyplot is the plotting interface.

**2. A single Figure can contain several Axes.**  _(True/False)_

- A) True ✅
- B) False

> **Answer: A.** Each Axes is one plot inside the Figure.

**3. Which draws a scatter plot?**  _(Multiple choice)_

- A) plt.plot(x, y, kind='s')
- B) plt.scatter(x, y) ✅
- C) plt.points(x, y)
- D) plt.bar(x, y)

> **Answer: B.** plt.scatter.

**4. Which saves the current figure to a file?**  _(Multiple choice)_

- A) `plt.show('f.png')`
- B) `plt.savefig('f.png')` ✅
- C) `plt.write('f.png')`
- D) `plt.export('f.png')`

> **Answer: B.** savefig writes PNG, PDF, SVG and more.

**5. Which argument gives a dashed line?**  _(Multiple choice)_

- A) `marker='--'`
- B) `linestyle='--'` ✅
- C) `color='--'`
- D) `dash=True`

> **Answer: B.** linestyle (or ls).

**6. Does `plt.legend()` need each series to have a `label`?**  _(Yes/No)_

- A) Yes ✅
- B) No

> **Answer: A.** Labels supply the legend entries.

