# Checkpoint 4.1 — Descriptive Statistics (Answer Key)

6 questions · untimed · covers Unit 4.1. Choose one answer per question.

**1. Which measure is most resistant to outliers?**  _(Multiple choice)_

- A) Mean
- B) Median ✅
- C) Range
- D) Variance

> **Answer: B.** The median depends only on the middle value(s).

**2. The most frequent value is the…**  _(Multiple choice)_

- A) mean
- B) median
- C) mode ✅
- D) range

> **Answer: C.** mode().

**3. Standard deviation is the square root of variance.**  _(True/False)_

- A) True ✅
- B) False

> **Answer: A.** std = sqrt(var).

**4. Income data has mean 52k and median 41k. It is probably…**  _(Multiple choice)_

- A) left-skewed
- B) right-skewed ✅
- C) symmetric
- D) uniform

> **Answer: B.** A long right tail pulls the mean above the median.

**5. Under the empirical rule, about what % of normal data lies within 2 sd of the mean?**  _(Multiple choice)_

- A) 68%
- B) 90%
- C) 95% ✅
- D) `99.7%`

> **Answer: C.** 68–95–99.7.

**6. Does `df.describe()` include the quartiles?**  _(Yes/No)_

- A) Yes ✅
- B) No

> **Answer: A.** 25%, 50% and 75% rows.

