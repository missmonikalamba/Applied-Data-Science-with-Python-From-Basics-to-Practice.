# Checkpoint 1.2 — Introduction to Pandas (Answer Key)

6 questions · untimed · covers Unit 1.2. Choose one answer per question.

**1. A Pandas Series is best described as…**  _(Multiple choice)_

- A) A table of columns
- B) A labelled 1D array ✅
- C) A Python dict
- D) A 2D NumPy array

> **Answer: B.** Series = values plus an index of labels.

**2. Creating a Series from a dict uses the dict keys as…**  _(Multiple choice)_

- A) values
- B) the index ✅
- C) column names
- D) dtypes

> **Answer: B.** Keys become index labels; values become data.

**3. Adding two Series aligns values by index label, not position.**  _(True/False)_

- A) True ✅
- B) False

> **Answer: A.** Pandas aligns on labels; unmatched labels give NaN.

**4. Which method shows column dtypes and non-null counts?**  _(Multiple choice)_

- A) `describe()`
- B) `head()`
- C) `info()` ✅
- D) shape

> **Answer: C.** info() lists each column, its non-null count and dtype.

**5. Which selects rows where age > 30 and only the 'fare' column?**  _(Multiple choice)_

- A) df[df.age > 30]['fare', :]
- B) df.loc[df.age > 30, 'fare'] ✅
- C) df.iloc[age > 30, 'fare']
- D) df.fare(age > 30)

> **Answer: B.** loc takes [row condition, column label].

**6. Does `df.tail()` show the last 5 rows by default?**  _(Yes/No)_

- A) Yes ✅
- B) No

> **Answer: A.** head() and tail() default to 5 rows.

