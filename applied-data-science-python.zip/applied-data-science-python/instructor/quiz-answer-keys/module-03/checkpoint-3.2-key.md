# Checkpoint 3.2 — Advanced Visualization Techniques (Answer Key)

9 questions · untimed · covers Unit 3.2. Choose one answer per question.

**1. `fig, axes = plt.subplots(2, 3)` creates how many Axes?**  _(Multiple choice)_

- A) 2
- B) 3
- C) 5
- D) 6 ✅

> **Answer: D.** 2 rows × 3 columns.

**2. Which adds an arrow pointing at a data point?**  _(Multiple choice)_

- A) `plt.text()`
- B) `plt.annotate()` ✅
- C) `plt.arrow_text()`
- D) `plt.title()`

> **Answer: B.** annotate with arrowprops.

**3. Best chart to show a trend over 24 months?**  _(Multiple choice)_

- A) Pie
- B) Line ✅
- C) Histogram
- D) Box plot

> **Answer: B.** Line charts show change over time.

**4. Best chart for the distribution of one numeric variable?**  _(Multiple choice)_

- A) Histogram ✅
- B) Pie
- C) Line
- D) Heatmap

> **Answer: A.** Histograms show spread and shape.

**5. Comparing salary spread across 4 departments: use…**  _(Multiple choice)_

- A) Pie chart
- B) Box plot ✅
- C) Line chart
- D) Scatter plot

> **Answer: B.** Box/violin plots compare distributions across groups.

**6. A pie chart with 15 slices is easy to read.**  _(True/False)_

- A) True
- B) False ✅

> **Answer: B.** Use a sorted bar chart instead.

**7. A heatmap is best for…**  _(Multiple choice)_

- A) one category
- B) a correlation matrix ✅
- C) a single trend
- D) a part-to-whole

> **Answer: B.** Colour encodes values across two dimensions.

**8. Which module formats dates on a Matplotlib axis?**  _(Multiple choice)_

- A) `matplotlib.dates` ✅
- B) `datetime.plot`
- C) `pandas.dates`
- D) `matplotlib.time`

> **Answer: A.** matplotlib.dates (mdates).

**9. Can a bar chart whose axis starts at 90 exaggerate small differences?**  _(Yes/No)_

- A) Yes ✅
- B) No

> **Answer: A.** Bars should start at zero.

