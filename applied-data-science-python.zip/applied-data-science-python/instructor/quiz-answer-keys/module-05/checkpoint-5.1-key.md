# Checkpoint 5.1 — Introduction to Machine Learning (Answer Key)

6 questions · untimed · covers Unit 5.1. Choose one answer per question.

**1. Machine learning is best described as…**  _(Multiple choice)_

- A) hand-coding rules
- B) learning patterns from data to make predictions ✅
- C) storing data
- D) drawing charts

> **Answer: B.** Models learn from examples.

**2. Predicting whether an email is spam is…**  _(Multiple choice)_

- A) regression
- B) classification ✅
- C) clustering
- D) reinforcement

> **Answer: B.** A category: spam or not.

**3. Grouping customers with no labels is…**  _(Multiple choice)_

- A) supervised
- B) unsupervised ✅
- C) reinforcement
- D) regression

> **Answer: B.** Clustering is unsupervised.

**4. Which function splits data into train and test sets?**  _(Multiple choice)_

- A) `train_test_split` ✅
- B) `split_data`
- C) `KFold.fit`
- D) `pd.split`

> **Answer: A.** sklearn.model_selection.train_test_split.

**5. Evaluating a model on its own training data gives an honest estimate of future performance.**  _(True/False)_

- A) True
- B) False ✅

> **Answer: B.** Use a held-out test set.

**6. Is reinforcement learning based on rewards from actions?**  _(Yes/No)_

- A) Yes ✅
- B) No

> **Answer: A.** The agent learns from trial, error and reward.

