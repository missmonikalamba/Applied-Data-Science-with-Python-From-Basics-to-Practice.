# Checkpoint 4.2 — Inferential Statistics (Answer Key)

7 questions · untimed · covers Unit 4.2. Choose one answer per question.

**1. A sample is…**  _(Multiple choice)_

- A) the whole group of interest
- B) a subset of the population that we measure ✅
- C) always biased
- D) a statistic

> **Answer: B.** We use samples to learn about populations.

**2. Splitting a population into groups and sampling from each is…**  _(Multiple choice)_

- A) simple random
- B) stratified ✅
- C) convenience
- D) cluster

> **Answer: B.** Stratified sampling.

**3. The CLT says sample means are approximately normal for large enough samples, even if the data is skewed.**  _(True/False)_

- A) True ✅
- B) False

> **Answer: A.** That is the Central Limit Theorem.

**4. Increasing sample size makes a confidence interval…**  _(Multiple choice)_

- A) wider
- B) narrower ✅
- C) unchanged
- D) invalid

> **Answer: B.** The standard error shrinks with sqrt(n).

**5. Which SciPy function gives a t-based confidence interval?**  _(Multiple choice)_

- A) `stats.t.interval` ✅
- B) `stats.norm.cdf`
- C) `stats.ttest_ind`
- D) `stats.ci`

> **Answer: A.** stats.t.interval(conf, df, loc, scale).

**6. r = −0.85 indicates…**  _(Multiple choice)_

- A) weak positive
- B) strong negative ✅
- C) no relationship
- D) causation

> **Answer: B.** Close to −1 is strongly negative.

**7. Does a strong correlation prove that one variable causes the other?**  _(Yes/No)_

- A) Yes
- B) No ✅

> **Answer: B.** Correlation is not causation.

