# Checkpoint 5.4 — Machine Learning Algorithms Deep Dive (Answer Key)

5 questions · untimed · covers Unit 5.4. Choose one answer per question.

**1. To predict house prices you would use…**  _(Multiple choice)_

- A) Logistic regression
- B) Linear regression ✅
- C) K-Means
- D) MinMaxScaler

> **Answer: B.** A continuous target.

**2. `StandardScaler` transforms each feature to…**  _(Multiple choice)_

- A) range 0–1
- B) mean 0, sd 1 ✅
- C) integers
- D) ranks

> **Answer: B.** z-scores.

**3. `MinMaxScaler` transforms each feature to…**  _(Multiple choice)_

- A) range 0–1 ✅
- B) mean 0, sd 1
- C) log scale
- D) percentiles

> **Answer: A.** (x − min) / (max − min).

**4. A Pipeline can chain a scaler and a model so both are fitted together.**  _(True/False)_

- A) True ✅
- B) False

> **Answer: A.** sklearn.pipeline.Pipeline.

**5. Should the scaler be fitted on the test set?**  _(Yes/No)_

- A) Yes
- B) No ✅

> **Answer: B.** Fit on training data only to avoid leakage.

