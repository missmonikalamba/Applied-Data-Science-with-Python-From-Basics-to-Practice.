# Checkpoint 1.1 — Introduction to NumPy (Answer Key)

6 questions · untimed · covers Unit 1.1. Choose one answer per question.

**1. Which attribute gives an array's dimensions as a tuple?**  _(Multiple choice)_

- A) ndim
- B) shape ✅
- C) size
- D) dtype

> **Answer: B.** shape returns a tuple such as (2, 3); ndim is the number of dimensions.

**2. All elements of a NumPy array share one data type.**  _(True/False)_

- A) True ✅
- B) False

> **Answer: A.** A single dtype is what makes arrays compact and fast.

**3. What does `np.arange(2, 10, 3)` return?**  _(Multiple choice)_

- A) [2, 5, 8] ✅
- B) [2, 5, 8, 11]
- C) [3, 6, 9]
- D) [2, 3, 4]

> **Answer: A.** Start at 2, step 3, stop before 10.

**4. `a` has shape (2, 3). What is `a.sum(axis=0).shape`?**  _(Multiple choice)_

- A) `(2,)`
- B) `(3,)` ✅
- C) (2, 3)
- D) `()`

> **Answer: B.** axis=0 collapses rows, leaving one value per column.

**5. `x = np.array([4, 9, 1, 7])`. What is `x[x > 5]`?**  _(Multiple choice)_

- A) [9, 7] ✅
- B) [True, False]
- C) [4, 1]
- D) [1, 3]

> **Answer: A.** A boolean mask keeps elements where the condition is True.

**6. Can a (3, 1) array be added to a (1, 4) array?**  _(Yes/No)_

- A) Yes ✅
- B) No

> **Answer: A.** Broadcasting stretches both to (3, 4).

