# Instructor guide

This folder holds everything learners should **not** see before an assessment. For graded cohorts, move this folder to a **private** repository (or your LMS) before publishing the course repository.

```
instructor/
├── answer-keys/            ← lab notebooks with full solutions (executed, outputs included)
├── quiz-answer-keys/       ← every checkpoint and module quiz with answers + feedback
└── lms-import/
    ├── moodle-gift/        ← one GIFT file per module (all checkpoints + module quiz)
    └── csv/                ← one CSV per quiz (question, options, correct answer, feedback, tier)
```

## Lab answer keys

- `answer-keys/Module01_NumPy_Pandas_Lab_ANSWER_KEY.ipynb`
- `answer-keys/Module02_Data_Cleaning_Lab_ANSWER_KEY.ipynb`
- `answer-keys/Module03_Visualization_Gallery_Lab_ANSWER_KEY.ipynb`
- `answer-keys/Module04_Statistics_Lab_ANSWER_KEY.ipynb`
- `answer-keys/Module05_ML_Algorithms_Lab_ANSWER_KEY.ipynb`

Each key was executed top to bottom in a clean Python environment with the course datasets, and every `assert` check passes. Student notebooks contain the same cells with `___` blanks or `# YOUR CODE HERE`.

## Hosting the quizzes

| Platform | How |
|---|---|
| **Moodle** | Question bank › Import › format *GIFT* › upload `lms-import/moodle-gift/module-0N.gift.txt`. Categories are created per checkpoint and module quiz. Then build quizzes from the categories, set the time limit (30–40 min for module quizzes) and enable immediate feedback. |
| **Google Forms** | Create a form, turn on *Settings › Make this a quiz*, then add questions from the CSV (or use a CSV-to-Forms add-on from the Google Workspace Marketplace). Add the `feedback` column as answer feedback for immediate feedback. |
| **H5P** | Use the *Question Set* or *Single Choice Set* content type and copy questions from the Markdown or CSV files. |
| **Paper** | Print `module-*/quizzes/*.md`; mark with the keys in `quiz-answer-keys/`. |

The module quiz difficulty mix follows the course design: **Recall 40% · Application 40% · Analysis 20%** (the `tier` column / tag on every question).

## Using the slide decks

- One uniform template across all decks (Cambria/Calibri, teal and amber palette, consistent layouts). Edit layouts in *View › Slide Master*.
- **Slide 1** of every deck has an introductory video placeholder: *Insert › Video › Online Video* and paste an openly licensed YouTube or Wikimedia Commons link.
- **Speaker notes** on every slide contain teaching notes; **checkpoint slides** have the answers and explanations in the notes.
- Every code example on the slides was run to produce the output shown, using the datasets in this repository.
- Decks are video-ready: record with *Slide Show › Record* for self-paced cohorts.

## Teaching tips

- Live-code the slide examples in Colab rather than only showing them; learners should predict outputs first.
- Module 2's raw retail file is deliberately messy: let learners discover the problems with `info()`, `value_counts()` and `describe()` before showing fixes.
- Module 4 emphasises interpretation. Ask learners to state every result as a plain-language sentence.
- Module 5: insist on a baseline for every classifier and on fitting scalers only on training data.
- Week 8: collect Final Project proposals (`final-project/proposal-template.md`) and give quick feedback on dataset choice.

## Library versions

Materials were tested with Python 3.13, pandas 3.0, NumPy 2, Matplotlib 3.11, Seaborn 0.13, SciPy 1.18, statsmodels 0.15 and scikit-learn 1.9, and use only APIs available in pandas ≥ 2.1 and Matplotlib ≥ 3.9 (the versions on Google Colab). `plt.plot_date()` from the original outline is deprecated, so the materials plot datetimes with `plot()` and format axes with `matplotlib.dates`.
