# Checkpoint 3.4 — Statistical Visualization with Seaborn (Answer Key)

8 questions · untimed · covers Unit 3.4. Choose one answer per question.

**1. Which Seaborn function draws a histogram?**  _(Multiple choice)_

- A) `sns.histplot` ✅
- B) `sns.barplot`
- C) `sns.hist`
- D) `sns.countplot`

> **Answer: A.** histplot (add kde=True for a curve).

**2. Which shows a smooth density estimate?**  _(Multiple choice)_

- A) `sns.kdeplot` ✅
- B) `sns.lineplot`
- C) `sns.boxplot`
- D) `sns.heatmap`

> **Answer: A.** KDE = kernel density estimate.

**3. `hue='species'` in a Seaborn call…**  _(Multiple choice)_

- A) sets the title
- B) colours points by species ✅
- C) filters species
- D) sorts by species

> **Answer: B.** hue maps a column to colour.

**4. Which counts rows per category?**  _(Multiple choice)_

- A) `sns.barplot`
- B) `sns.countplot` ✅
- C) `sns.histplot`
- D) `sns.scatterplot`

> **Answer: B.** countplot.

**5. By default, `sns.barplot` shows the mean with a confidence interval.**  _(True/False)_

- A) True ✅
- B) False

> **Answer: A.** Bar height is the mean; the line is the CI.

**6. Which is figure-level and can facet with `col=`?**  _(Multiple choice)_

- A) `sns.histplot`
- B) `sns.displot` ✅
- C) `sns.kdeplot`
- D) `sns.boxplot`

> **Answer: B.** displot creates its own figure and facets.

**7. Best Seaborn chart for a correlation matrix?**  _(Multiple choice)_

- A) `sns.heatmap` ✅
- B) `sns.violinplot`
- C) `sns.countplot`
- D) `sns.lineplot`

> **Answer: A.** heatmap with annot=True.

**8. Does `sns.violinplot` show the shape of each group's distribution?**  _(Yes/No)_

- A) Yes ✅
- B) No

> **Answer: A.** It combines a box plot with a mirrored KDE.

