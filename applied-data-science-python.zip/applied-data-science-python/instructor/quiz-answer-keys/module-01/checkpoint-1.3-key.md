# Checkpoint 1.3 — Data Input/Output (Answer Key)

5 questions · untimed · covers Unit 1.3. Choose one answer per question.

**1. Which parameter reads only some columns from a CSV?**  _(Multiple choice)_

- A) nrows
- B) usecols ✅
- C) header
- D) `index_col`

> **Answer: B.** usecols takes a list of column names or positions.

**2. Which function reads a .xlsx file?**  _(Multiple choice)_

- A) `pd.read_csv`
- B) `pd.read_excel` ✅
- C) `pd.read_xlsx`
- D) `pd.open_excel`

> **Answer: B.** read_excel (needs the openpyxl package).

**3. `df.to_csv('f.csv')` writes the index as a column by default.**  _(True/False)_

- A) True ✅
- B) False

> **Answer: A.** Pass index=False to leave it out.

**4. To write a semicolon-separated file you set…**  _(Multiple choice)_

- A) `sep=';'` ✅
- B) `delimiter=False`
- C) `encoding=';'`
- D) `split=';'`

> **Answer: A.** sep controls the field separator.

**5. Does `nrows=100` read only the first 100 data rows?**  _(Yes/No)_

- A) Yes ✅
- B) No

> **Answer: A.** Useful for previewing very large files.

